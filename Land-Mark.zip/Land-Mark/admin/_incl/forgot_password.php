<?php
include 'DB.php';
$email=$_POST['email'];
    $sql="SELECT * FROM admin WHERE email='$email'";
$go= mysqli_query($conn, $sql);
if($go){ 
header("Location:../password_renew.php");
}