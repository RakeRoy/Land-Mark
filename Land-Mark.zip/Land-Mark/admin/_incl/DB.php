<?php
$host="localhost";
$user="root";
$pass="";             
$DB="land_mafia";          // checked by Mahad
$conn= new mysqli($host,$user,$pass,$DB);
/*
if($conn->connect_error)
{
    echo'Connection Falied';
}
else
{
    echo'Connected';
} */