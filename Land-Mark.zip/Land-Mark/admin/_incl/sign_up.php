<?php
include'DB.php';
$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$dob=$_POST['dob'];
$password=md5($_POST['password']);
$new_password=md5($_POST['new_password']);
$gender=$_POST['gender'];
if($_POST['check_box'])
{
if($new_password!=$password)
{
   echo'<script>alert("Password Does not Match");</script>';
}
else{
$sql="INSERT INTO `admin`(`id`, `name`, `email`, `password`, `dob`,`gender`) VALUES ('$id','$name','$email','$password','$dob','$gender')";


mysqli_query($conn, $sql);

$sql = "SELECT MAX(id) as ID FROM admin";
$ID = mysqli_query($conn, $sql);
$ID = mysqli_fetch_assoc($ID);
$ID = $ID ['ID'];
$path="../../../user_pics/";
$file_name = $_FILES ['image']['tmp_name'];
move_uploaded_file ($file_name, $path .$ID. ".jpg");
header("Location: ../login.php");    
}
}
else{
    echo "Your Must Agree Terms";
}