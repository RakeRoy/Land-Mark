<?php
include'db.php';

$doc_name=$_POST['doc_name'];
$doc_email=$_POST['doc_email'];
$type=$_POST['type'];
$doc_loc=$_POST['doc_address'];
$doc_num=$_POST['doc_num'];

$sql="INSERT INTO `doctor_data`(`doc_name`, `doc_email`, `doc_type`, `doc_address`, `doc_phone`) VALUES ('$doc_name','$doc_email','$type','$doc_loc','$doc_num')";

$result= mysqli_query($conn, $sql);

//Picture Savaing Code
$sql = "SELECT MAX(id) as ID FROM doctor_data";
$ID = mysqli_query($conn, $sql);
$ID = mysqli_fetch_assoc($ID);
$ID = $ID ['ID'];
$path="../../doc_pics/";
$file_name = $_FILES ['image']['tmp_name'];
move_uploaded_file ($file_name, $path .$ID. ".jpg");

header("Location:../doctor_data_table.php");