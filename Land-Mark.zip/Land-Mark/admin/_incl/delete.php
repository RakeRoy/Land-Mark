<?php
include 'DB.php';
$id=$_REQUEST['id'];
$sql="DELETE FROM `code` WHERE id=$id";
mysqli_query($conn,$sql);
header("Location:../show_programs_table.php");