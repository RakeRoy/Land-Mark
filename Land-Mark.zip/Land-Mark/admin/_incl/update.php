<?php include 'DB.php';
$name=$_POST['name'];
$id=$_REQUEST['id'];
$sql="UPDATE `code` SET `name`=$name WHERE id=$id";
mysqli_query($conn, $sql);
header("location:../show_programs_table.php");

$sql="SELECT MAX(id) as ID FROM code";
$ID = mysqli_query($conn, $sql);
$ID = mysqli_fetch_assoc($ID);
$ID = $ID ['ID'];
//Folder Path Variable
$path1="../../../codes_data/codes_files/";
$path2="../../../codes_data/codes_output/";

//Move Image File To The Folder
$img_file=$_FILES['picture']['tmp_name'];
move_uploaded_file($img_file,$path2 .$ID. ".jpg");

//Move CPP File To The Folder
$CPP_name=$_FILES['cpp_name']['tmp_name'];
move_uploaded_file($CPP_name,$path1 .$ID. ".cpp");

//Set Location After Submition

