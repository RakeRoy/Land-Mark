<?php
if(!isset($_SESSION['username']))
{
    include '500.php'; exit;
} 
?>