<?php include '_incl/check.php'; ?>
<?php include '_incl/head.php'; ?>
<?php include '_incl/navbar.php'; ?>
<?php include '_incl/sidebar_container.php'; ?>
<?php include '_incl/wrapper.php'; ?>
<div class="card">
            <div class="card-header">
              <h3 class="card-title">Coming Soon</h3>
            </div>
            <!-- /.card-header -->
<!--            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Program Name</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                <?php
                include'_incl/DB.php';
                $sql="SELECT * FROM code";
                $result= mysqli_query($conn, $sql);
                foreach($result as $data)
                {
                    echo"<td>".$data['name']."</td> "
                            . "<td> <div class='btn-group'>
                    <button type='button' class='btn btn-info'>Action</button>
                    <button type='button' class='btn btn-info dropdown-toggle' data-toggle='dropdown'>
                      <span class='caret'></span>
                      <span class='sr-only'>Toggle Dropdown</span>
                    </button>
                    <div class='dropdown-menu' role='menu'>
                      <a class='dropdown-item' href='_incl/delete.php?id=" . $data['id']. " &from=code'>Delete</a>
                      <a class='dropdown-item' href='updation_form.php?id=" . $data['id']. "'>Update</a>
                    </div>
                  </div> </td>
                  
                  </tr>"
                            ;
                  
                }
                    
                  ?>
                
                </tbody>
                <tfoot>
                <tr>
                  <th>Program Name</th>
                </tr>
                </tfoot>
              </table>
            </div>-->
            <!-- /.card-body -->
          </div>
    <?php include '_incl/footer.php'; ?>
