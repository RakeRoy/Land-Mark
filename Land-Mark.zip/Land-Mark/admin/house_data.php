<?php session_start(); ?>
<?php include '_incl/check.php'; ?>
<?php include '_incl/head.php'; ?>
<?php include '_incl/navbar.php'; ?>
<?php include '_incl/sidebar_container.php'; ?>
<?php include '_incl/wrapper.php'; ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Style CSS -->
    <link rel="stylesheet" href="../south/style.css">


</head>
<div class="container">
<div class="col-md-6">
            <!-- general form elements -->
            <h1>All the Properties Data</h1>
</div>


<div class="row">
                        <!-- Property Thumbnail -->
<?php include '../db.php';
	$sql="SELECT * FROM house_sell ";
	$result=mysqli_query($connection,$sql);

	foreach($result as $data)
	{
	// $data['id']=$_SESSION['id'];
	    echo"

	                <!-- Single Featured Property -->
	                <div class='col-12 col-md-6 col-xl-4'>
	                    <div class='single-featured-property mb-50'>

	                        <div class='property-thumb'>
	                            <img style='width:100%; height:200px' src='../images/".$data['id'].".jpg'  alt=''>

	                            <div class='tag'>
	                                <span>For Sale</span>";
	                                if(isset($_SESSION['username']))
	                                {
	                                    if($_SESSION['username']==$data['owner_name'] || $_SESSION['username'] == 'Admin')
	                                    {
	                                        echo "<a href='house_data_edit.php?id=".$data['id']."'><img align='right' style='width:30px; height:30px; margin-left:10px;'src='../south/img/icons/edit.png' alt='Edit'></a>";
	                                        echo "<a href='../backend_func/DeleteOne.php?id=".$data['id']."'><img align='right' style='width:30px; height:30px;'src='../south/img/icons/delete.png' alt='Delete'></a>";
	                                    }
	                                }
	                            echo"</div>

	                            <div class='list-price'>
	                                <p>Rs.". $data['house_price']. "</p>
	                            </div>
	                        </div>
	                        <!-- Property Content -->
	                        <div class='property-content'>
	                            <h5>". $data['title']."</h5>
	                            <p class='location'><img src='img/icons/location.png' alt=''>" .$data['location']."</p>
	                            <p>". $data['description']."</p>
	                            <div class='property-meta-data d-flex align-items-end justify-content-between'> "
	                                
	                                // <div class='bathroom'>
	                                    
	                                //     <span><b style ='color:#947054'>Owner: </b> ". $data['owner_name'] ."</span>
	                                // </div> 
	                                ."
	                                <div class='garage'>

	                                    <span><b style ='color:#947054'>Phone: </b> ". $data['owner_ph'] . "</span>
	                                    <span> <b style='color:#947054'>Owner:</b> ".$data['owner_name']." </span>
	                                <div class='space'>
	                                </div>

	                                    
	                                    <span><b style ='color:#947054'>Area: </b>" .$data['marla_sq_ft'] . "sq ft</span>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>";
	            };

?>
<?php include '_incl/footer.php'; ?>
