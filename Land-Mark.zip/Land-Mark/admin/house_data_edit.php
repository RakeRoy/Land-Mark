<?php session_start(); ?>
<?php include'../db.php';?>
<?php include '_incl/check.php'; ?>
<?php include '_incl/head.php'; ?>
<?php include '_incl/navbar.php'; ?>
<?php include '_incl/sidebar_container.php'; ?>
<?php include '_incl/wrapper.php'; ?>
<div class="container">
<div class="col-md-6">
            <!-- general form elements -->
            <h1>All the Properties Data</h1>
</div>


<?php


$id=$_GET['id'];
$_SESSION['IDD']=$id;
//echo "Sup ". $id;
$query="SELECT * FROM `house_sell` WHERE id = '$id'";
$result = mysqli_query($connection, $query);
$data = mysqli_fetch_assoc($result);

//header("Location: south/listings.php");

// if(!isset($_SESSION['username']))
// {
//     echo"<script>alert('You need to login first')</script>";
//      echo"<a href='../Login.php'>Go back to login page</a> because ";
//      die("you need to login first");
//      //echo"<input type='submit' ";
//     // header("Location: ../Login.php");
// }

$username = $_SESSION['username']
?>

<!Doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Edit</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="css/style.css">
   <style>


* {
  box-sizing: border-box;
}



/* Full-width input fields */
input[type=text], input[type=password], textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #DADADA;
}

textarea{
    height: 150px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #B9B9B9;
  outline: none;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #947054;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  float:center;

  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

.label
{
    color:#947054;
    font-weight: bold;
}
    </style> 

    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>South - Real Estate Agency Template | Listings</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Preloader -->
  <!--   <div id="preloader">
        <div class="south-load"></div>
    </div> -->	

    <!-- ##### Breadcumb Area Start ##### -->
    <section class="breadcumb-area bg-img" style="background-image: url(img/bg-img/hero1.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-content">
                        <h3 class="breadcumb-title">SELL YOUR PROPERTY</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
<section class="listings-content-wrapper section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="listings-top-meta d-flex justify-content-between mb-25">
                        <div class="view-area d-flex align-items-center">

                        </div>
                    </div>
                </div>
            </div>

    <!-- ##### Breadcumb Area End ##### -->


    <!-- ##### Advance Search Area End ##### -->

    <!-- ##### Listing Content Wrapper Area Start ##### -->



 <div class="container">
      <div class="row">

        <div class="col-md1 col-lg-1 col-sm-1 col-xs-1">
        </div>

        <div class="col-md-10 col-lg-10 col-sm-10 col-xs-10"> 

            <form action="house_edit_creation.php" method = "POST" enctype="multipart/form-data">

            <!-- <label class="label" for="Name" >Owner's Name</label>
            <input type="text" name = "owner_name" id="Name" value="<?php //echo $username; ?>" placeholder="Enter Name"> -->

            <label class="label" for="Phone"> Phone Number </label>
            <input type="text" name = "owner_ph" id="Phone" placeholder="Enter Phone Number" value ='<?php  echo $data['owner_ph'] ?>'required>

            <label class="label" for="price"> Price </label>
            <input type="text" name = "price" id="price" placeholder="Enter Price in Rs." value ='<?php  echo $data['house_price'] ?>' required>

            <label class="label" for="area"> House Size </label>
            <input type="text" name = "area" id ="area" placeholder="Enter Size in Sq Ft." value ='<?php  echo $data['marla_sq_ft'] ?>' required>


            <label class="label" for="title"> Title: </label>
            <input type="text" name = "title" id="title" placeholder="Enter Post Title" value ='<?php  echo $data['title'] ?>' required>


            <label class="label" for="description"> Description </label>
            <input type='text' name = "description" id="description" style='height:150px;' placeholder="Enter Short Description of What You Are Selling i.e. 2 Bathrooms, 2 Bedrooms etc." value ='<?php  echo $data['description'] ?>' required></input>

            <label class="label" for="location"> Location </label>
            <input type="text" name = "location" id="location" placeholder="Enter Address of Property" value ='<?php  echo $data['location'] ?>' required>


            <label> Image upload </label>
            <input type="file" name= "image" required> 

            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
            </div>

            <div class="col-md-6 col-lg-6 col-sm-6 col-xs-6">
            <input type="submit" name='submit' class="registerbtn"></input>
            </div>

            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
            </div>

        </div>
        <div class="col-md-1 col-lg-1 col-sm-1 col-xs-1">
      </div>

</form>
</div>
</div>
</div>	
<?php include '_incl/footer.php'; ?>
